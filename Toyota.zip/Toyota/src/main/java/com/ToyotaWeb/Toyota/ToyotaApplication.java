package com.ToyotaWeb.Toyota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToyotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToyotaApplication.class, args);
	}

}
