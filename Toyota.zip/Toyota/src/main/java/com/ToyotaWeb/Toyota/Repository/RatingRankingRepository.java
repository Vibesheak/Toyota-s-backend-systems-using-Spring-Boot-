package com.ToyotaWeb.Toyota.Repository;

import com.ToyotaWeb.Toyota.Model.RatingRanking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RatingRankingRepository extends JpaRepository<RatingRanking, Long> {
}
